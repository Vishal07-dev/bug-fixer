import axios from "axios";
import inquirer from "inquirer";

const check = async () => {
  const email = await inquirer.prompt([
    {
      type: "input",
      name: "email",
      message: "Enter your email:",
    },
  ]);
  try {
    const { data } = await axios.post(
      "http://localhost:8000/api/auth/checkUser",
      {
        email: email.email,
      }
    );
    if (data.user) {
      return login(email.email);
    } else {
      return register(email.email);
    }
  } catch (error) {
    console.error("Error during login:", error.response.data.message);
  }
};

const login = async (email) => {
  const password = await inquirer.prompt([
    {
      type: "input",
      name: "password",
      message: "Enter your password:",
    },
  ]);
  try {
    const { data } = await axios.post("http://localhost:8000/api/auth/login", {
      email: email,
      password: password.password,
    });
    console.log("Login successful:", data);
    return data;
  } catch (error) {
    console.error("Error during login:", error.response.data.message);
  }
};

const register = async (email) => {
  const password = await inquirer.prompt([
    {
      type: "input",
      name: "password",
      message: "Enter your password:",
    },
  ]);
  try {
    const { data } = await axios.post(
      "http://localhost:8000/api/auth/register",
      {
        email,
        password: password.password,
      }
    );
    return data;
  } catch (error) {
    console.error("Error during registration:", error.response.data.message);
  }
};

export default check;
