import fs from "fs";
import path from "path";

/**
 * Recursively creates folders and files based on the provided structure.
 * @param {Array} structure - The folder/file structure as an array of objects.
 * @param {string} parentPath - The parent directory path (default is the current working directory).
 */
export default function createStructure(structure, parentPath = ".") {
  structure.forEach((item) => {
    const [key, value] = Object.entries(item)[0]; // Get the first (and only) key-value pair

    const fullPath = path.join(parentPath, key); // Create full path

    if (value.type === "folder") {
      // Create folder if it doesn't exist
      if (!fs.existsSync(fullPath)) {
        fs.mkdirSync(fullPath, { recursive: true });
        console.log(`📂 Created folder: ${fullPath}`);
      }

      // Recursively create children inside this folder
      if (Array.isArray(value.children)) {
        createStructure(value.children, fullPath);
      }
    } else if (value.type === "file") {
      // Join array content into a string with new lines
      const fileContent = Array.isArray(value.content)
        ? value.content.join("\n")
        : value.content;

      // Write file content
      fs.writeFileSync(fullPath, fileContent, "utf8");
      console.log(`📄 Created file: ${fullPath}`);
    }
  });
}
