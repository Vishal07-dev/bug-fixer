import fs from "fs";
export default function applyFixes(fixesArray) {
  fixesArray.forEach(({ filePath, fixedCode }) => {
    fs.writeFileSync(filePath, fixedCode, "utf-8");
    console.log(`\n✅ Updated: ${filePath}`);
  });
}
