import loading from "loading-cli";

export const load = loading("loading..", "gray");

load.frame(["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]);
