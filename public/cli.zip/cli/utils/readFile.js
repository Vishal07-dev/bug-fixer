import fs from "fs";
import path from "path";

const TEMP_STORAGE = {}; // Store file contents

// Configurable arrays for ignored folders, files, and allowed extensions
const IGNORED_FOLDERS = ["node_modules", ".git", "dist", "build", "coverage"];
const IGNORED_FILES = [".env", ".gitignore", "package-lock.json", "yarn.lock"];
const ALLOWED_EXTENSIONS = [
  ".js",
  ".ts",
  ".jsx",
  ".tsx",
  ".css",
  ".html",
  ".json",
  ".md",
  ".py",
  ".php",
  ".java",
  ".c",
  ".cpp",
  ".h",
  ".go",
  ".rb",
  ".swift",
  ".sh",
  ".bash",
  ".sql",
  ".xml",
  ".yaml",
  ".yml",
  ".toml",
  ".ini",
  ".properties",
  ".txt",
  ".log",
  ".csv",
  ".tsv",
  ".xls",
]; // Add ".py" here

/**
 * Recursively reads a directory and builds a folder structure along with file contents.
 */
function readFilesRecursively(dir) {
  let structure = {}; // Folder structure

  const files = fs.readdirSync(dir);
  files.forEach((file) => {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);

    if (stat.isDirectory()) {
      if (!IGNORED_FOLDERS.includes(file)) {
        structure[file] = readFilesRecursively(filePath); // Recursively get folder structure
      }
    } else {
      const fileExt = path.extname(file);
      if (
        !IGNORED_FILES.includes(file) &&
        ALLOWED_EXTENSIONS.includes(fileExt)
      ) {
        const content = fs.readFileSync(filePath, "utf-8");
        TEMP_STORAGE[filePath] = content; // Store original content
        structure[file] = { content }; // Store content in structure
      }
    }
  });
  return structure;
}

// Export the function and TEMP_STORAGE
export { readFilesRecursively, TEMP_STORAGE };
