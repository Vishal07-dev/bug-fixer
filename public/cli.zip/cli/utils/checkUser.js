import { fileURLToPath } from "url";
import { dirname } from "path";
import path from "path";
import fs from "fs";
import readline from "readline";
import axios from "axios";
import login from "./Auth.js";

// Get __dirname equivalent
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const userPath = path.join(__dirname, "..", "user.json");

async function checkUserEmail(callback) {
  if (fs?.existsSync(userPath)) {
    const userData = JSON?.parse(fs?.readFileSync(userPath, "utf8"));

    if (userData?.email) {
      callback(userData.email);
    } else {
      const data = await login(callback);
      fs?.writeFileSync(userPath, JSON?.stringify({ email: data.user.email }));
      callback(data.email);
    }
  } else {
    const data = await login(callback);
    fs?.writeFileSync(userPath, JSON?.stringify({ email: data.user.email }));
    callback(data.email);
  }
}

export default checkUserEmail;

export async function readUserEmail() {
  if (fs.existsSync(userPath)) {
    const userData = JSON.parse(fs.readFileSync(userPath, "utf8"));
    return userData.email;
  } else {
    return null;
  }
}
