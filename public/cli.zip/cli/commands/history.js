import axios from "axios";
import { readUserEmail } from "../utils/checkUser.js";
import chalk from "chalk";
import formatCustomDate from "../utils/Date.js";
export const getHistory = async () => {
  const email = await readUserEmail();
  try {
    const { data } = await axios.get(
      `http://localhost:8000/api/commands/history/${email}`
    );

    if (data.data?.length > 0) {
      console.log("");
      console.log(`${"prompt".slice(0, 40).padEnd(60)} |  Date`);
      console.log(
        "-------------------------------------------------------------------------------------"
      );
      data.data.forEach((item) => {
        const date = formatCustomDate(item.createdAt);
        console.log(`${item.prompt.slice(0, 40).padEnd(60)} ${date}`);
      });

      console.log("");
    } else {
      console.log(chalk.yellow("No history found."));
    }
  } catch (error) {
    console.log("Error:", error.message);
  }
};
