import inquirer from "inquirer";
import { load } from "../utils/spiner.js";
import createStructure from "../utils/writeFs.js";
import axios from "axios";
import { readUserEmail } from "../utils/checkUser.js";

export default function cfs() {
  inquirer
    .prompt([
      {
        type: "input",
        name: "problem",
        message: "for which you want to create folder structure?",
        default: "for ecommerce frontend",
      },
    ])
    .then(async (prompt) => {
      load.start();
      load.text = "Generating folder structure...";

      try {
        const email = await readUserEmail();
        const { data } = await axios.post(
          "http://localhost:8000/api/commands/cfs",
          {
            problem: prompt.problem,
            email,
          }
        );
        load.text = "Applying folder structure...";
        console.log("");
        createStructure(data.response);
        load.stop();
        console.log("Folder structure created successfully");
      } catch (error) {
        load.stop();
        console.log("/nError:", error.message);
      }
    });
}
