import inquirer from "inquirer";
import { load } from "../utils/spiner.js";
import { readFilesRecursively } from "../utils/readFile.js";
import applyFixes from "../utils/writeFile.js";
import axios from "axios";

export default function fix() {
  inquirer
    .prompt([
      {
        type: "input",
        name: "problem",
        message: "What is the problem?",
        default: "I am getting an error",
      },
    ])
    .then(async (problem) => {
      load.start();
      load.text = "Reading files...";
      const projectDir = process.cwd(); // Get current project directory
      const folderStructure = readFilesRecursively(projectDir);
      load.text = "Getting fix from AI...";
      try {
        const { data } = await axios.post(
          "https://bug-detection.vercel.app/api/commands/fix",
          {
            problem: problem.problem,
            code: folderStructure,
          }
        );
        load.text = "Applying fixes...";
        applyFixes(
          JSON.parse(data.replace(/```[a-zA-Z]*\n([\s\S]*?)```/g, "$1").trim())
        );
        load.stop();
        console.log("\nFixes applied successfully");
      } catch (error) {
        console.log("Error:", error.message);
      }
    });
}
