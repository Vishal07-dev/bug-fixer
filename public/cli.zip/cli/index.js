#!/usr/bin/env node

import dotenv from "dotenv";
import inquirer from "inquirer";
import figlet from "figlet";
import chalk from "chalk";
import fix from "./commands/fix.js";
import { pastel } from "gradient-string";
import cfs from "./commands/cfs.js";
import dns from "dns";
import checkUserEmail from "./utils/checkUser.js";
import { getHistory } from "./commands/history.js";

dotenv.config();
const args = process.argv.slice(2);

figlet("Welcome to BugFixer", function (err, data) {
  if (err) {
    console.log("Something went wrong...");
    return;
  }
  console.log("");
  console.log(pastel.multiline(data));
  console.log("");

  dns.resolve("www.google.com", function (err) {
    if (err) {
      console.log(
        chalk.red("No internet connection, please check your internet")
      );
    } else {
      checkUserEmail((email) => begin());
    }
  });
});

const begin = () => {
  if (args[0] === undefined) {
    inquirer
      .prompt({
        type: "list",
        name: "command",
        message: "What do you want to do?",
        choices: ["fix", "cfs", "sh", "help"],
      })
      .then((answer) => {
        if (answer.command === "fix") {
          fix();
        } else if (answer.command === "cfs") {
          cfs();
        } else if (answer.command === "help") {
          help();
        } else if (answer.command === "sh") {
          getHistory();
        }
      });
  }

  if (args[0] === "fix") {
    fix();
  }
  if (args[0] === "cfs") {
    cfs();
  }
  if (args[0] === "sh") {
    getHistory();
  }
};
